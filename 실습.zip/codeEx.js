const pet = {
    name: '구름',
    eat: function (food){
 console.log(`${this.name}은 ${food}를 먹습니다.`)
    }
}
pet.eat('밥')