class Product{
    constructor(name, weight, price){
        this.name=name;
        this.weight=weight;
        this.price=price;
    }
    calculate(weight){
        return this.price*(weight/this.weight);
    }
}
let product=new Product('돼지삼겹살',100,1690);
console.log(`${product.name}${product.weight}g의 가격은 ${product.calculate(200)}원 입니다.`);
