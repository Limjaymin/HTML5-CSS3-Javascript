const data = [{
    name: '일벌레',
    mineral: 50,
    gas: 0,
    supply: 1
}, {
    name: '여왕',
    mineral: 150,
    gas: 0,
    supply: 2
},{
    name: '바퀴',
    mineral: 75,
    gas: 25,
    supply: 2
},{
    name: '히드라리스크',
    mineral: 100,
    gas: 50,
    supply: 2
},{
    name: '타락귀',
    mineral: 150,
    gas: 100,
    supply: 2

}]

console.log(JSON.stringify(data, null, 2))