let object = {
    name : 'Nature of Code',
    price : 30000,
    author : '다니엘 쉬프만',
    isbn : 978896881901,
    페이지수 : 620
}
console.log(object);